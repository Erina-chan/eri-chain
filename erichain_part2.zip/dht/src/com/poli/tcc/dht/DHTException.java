package com.poli.tcc.dht;

public class DHTException {

	public static class UsernameAlreadyTakenException extends Exception {};
	
}
