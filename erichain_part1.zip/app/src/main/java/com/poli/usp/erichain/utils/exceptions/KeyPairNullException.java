package com.poli.usp.erichain.utils.exceptions;

/**
 * Created by mayerlevy on 10/10/17.
 */

public class KeyPairNullException extends Exception {
}
