package com.poli.usp.erichain.ui.dht_visualization;

import com.poli.usp.erichain.ui.base.MvpView;

/**
 * Created by Bruno on 02-Nov-17.
 */

public interface DhtVisualizationMvpView extends MvpView {

}
