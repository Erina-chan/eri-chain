package com.poli.usp.erichain.utils.exceptions;

/**
 * Created by mayerlevy on 10/16/17.
 */

public class CouldNotEncryptException extends Exception {
}
